
/**
 * This class is used to represent nodes in the Merkle Tree.
 * Task 1: Developed the constructor and the set and get methods of all the instance variables of this class.
 * @author Dareen Abdullah G01273954.
 */
public class MerkleTreeNode{

	/** Private instance variable parent of Node.*/
	private MerkleTreeNode parent;
	/** Private instance variable left child of Node.*/
	private MerkleTreeNode left;
	/** Private instance variable right child of Node.*/
	private MerkleTreeNode right;
	/** Private instance variable contents of Node.*/
	private String str;

	/**
	 * Zero-Param constructor.
	 */
	public MerkleTreeNode(){
		parent = null;
		left = null;
		right = null;
		str = null;
	}
	
	/**
	 * Paramterized Constructor.
	 * @param parent parent of the node
	 * @param left left child of the node
	 * @param right right child of the node
	 * @param str contents of the node
	 */
	public MerkleTreeNode(MerkleTreeNode parent,MerkleTreeNode left,MerkleTreeNode right,String str){
		this.parent = parent;
		this.left = left;
		this.right = right;
		this.str = str;
	}

	/**
	 * Getter Method for parent variable.
	 * @return MerkleTreeNode the parent
	 */
	public MerkleTreeNode getParent(){
		return parent;
	}

	/**
	 * Getter Method for left child variable.
	 * @return MerkleTreeNode the left chld
	 */
	public MerkleTreeNode getLeft(){
		return left;
	}
		
	/**
	 * Getter Method for right child variable.
	 * @return MerkleTreeNode the right child
	 */
	public MerkleTreeNode getRight(){
		return right;
	}

	/**
	 * Getter Method for str variable.
	 * @return String contents of the node
	 */
	public String getStr(){
		return str;
	}
	
	/**
	 * Setter Method for parent variable.
	 * @param parent a parent node
	 */
	public void setParent(MerkleTreeNode parent){
		//throw IllegalArgumentException for invalid parameters
		if (parent == null){
			throw new IllegalArgumentException();
		}
		this.parent = parent;
	}

	/**
	 * Setter Method for left child variable.
	 * @param left a left child node
	 */
	public void setLeft(MerkleTreeNode left){
		//throw IllegalArgumentException for invalid parameters
		if (left == null){
			throw new IllegalArgumentException();
		}
		this.left = left;
	}

	/**
	 * Setter Method for right child variable.
	 * @param right a right child node
	 */
	public void setRight(MerkleTreeNode right){
		//throw IllegalArgumentException for invalid parameters
		if (right == null){
			throw new IllegalArgumentException();
		}
		this.right = right;
	}

	/**
	 * Setter Method for str variable.
	 * @param str a left child node
	 */
	public void setStr(String str){
		//throw IllegalArgumentException for invalid parameters
		if (str == null){
			throw new IllegalArgumentException();
		}
		this.str = str;
	}        
        
}