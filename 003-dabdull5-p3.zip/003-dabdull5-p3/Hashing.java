/**
 * Crypt Hashing Class.
 * @author unknown.
 */
public class Hashing extends SHA512 {
    
    /**
     * Static cryptHash method.
     * @param s String to hash
     * @return String hashed string
     */
    public static String cryptHash(String s) {
        String digest = hashSHA512(s);
        return digest.substring(0,128);
    }
}
