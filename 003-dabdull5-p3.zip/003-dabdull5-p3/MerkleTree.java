import java.util.*;

/**
 * This is the class representing the complete MerkleTree.
 * @author Dareen Abdullah G01273954
 */
public class MerkleTree {

	/**public static class variable root; the head of the tree.*/
	public static MerkleTreeNode root;

	/**public instance variable numberOfFiles; integer to store num of files.*/
	public int numberOfFiles;

	/**public instance variable leaves: an arraylist of MerkleTreeNodes representing the files.*/
	public ArrayList<MerkleTreeNode> leaves;

	/**
	 * The method creates the entire MerkleTree by taking the files.
	 * and making them the leaves of the tree.
	 * @param files an array of strings representing the files
	 * @return String the hash code of the root
	 */
	public String constructMerkleTree(String[] files){
		//Task 3: You are required to develop the code for the constructMerkleTree method.
		//Running time complexity of this method: O(n) where n is the number of files (size of the files array)
		//You can assume that the size of the files will be given as 2^n
		//throw IllegalArgumentException for invalid parameters

		//If the files is null or length is 0 or not 2^n throw an illegalArgumentException
		if (files == null || files.length <= 1){
			throw new IllegalArgumentException();
		}

		//calculate the depth by using math.log
		int depth = (int) (Math.log(files.length) / Math.log(2));

		
		//Two to the power of the depth must always equal the length otherwise the given file is not of size 2^n
		if (Math.pow(2,depth) != files.length){
			throw new IllegalArgumentException();
		}
		
		numberOfFiles = files.length;
		leaves = new ArrayList<MerkleTreeNode>();

		root = new MerkleTreeNode();

		//Calls a recursive function: Running time complexity is O(2*log(n)) or O(log(n))
		root = buildMerkle(0, 0, depth, files, root);

		return root.getStr();
	}


	/**
	 * Private recursive helper method.
	 * @param m represents the current level the algorithm is working on.
	 * @param n the node on that level.
	 * @param depth the depth of whole tree
	 * @param files an array of strings reperesnting the files
	 * @param parent the current parent, starting from root to the parent of files
	 * @return MerkleTreeNode the parent node
	 */
	private MerkleTreeNode buildMerkle(int m,int n, int depth, String[] files, MerkleTreeNode parent){
		
		if (m < depth-1){

			//Create the two children of current parent
			//each child will become the parent to the next recursive call
			MerkleTreeNode siblingA = new MerkleTreeNode();
			siblingA = buildMerkle(m+1, 2*n, depth, files, siblingA);
			siblingA.setParent(parent);

			MerkleTreeNode siblingB = new MerkleTreeNode();
			siblingB = buildMerkle(m+1, (2*n) + 1, depth, files, siblingB); 
			siblingB.setParent(parent);

			parent.setLeft(siblingA);
			parent.setRight(siblingB);
			parent.setStr(Hashing.cryptHash(siblingA.getStr() + siblingB.getStr()));

			//returns the parent after all the recursive calls and setting the hash code
			return parent;
		}

		else{

			//base case
			//once the parent of the files is reached or m = 1
			MerkleTreeNode leafA = new MerkleTreeNode();

			//if the file is null throw error
			if (files[2*n] == null){
				throw new IllegalArgumentException();
			}
      		leafA.setStr(files[2*n]);
      		leafA.setParent(parent);
      		leaves.add(leafA);
      
     		MerkleTreeNode leafB = new MerkleTreeNode();

			//if the file is null throw error
			if (files[2*n + 1] == null){
     			throw new IllegalArgumentException();
     		}
      		leafB.setStr(files[2*n + 1]);
      		leafB.setParent(parent);
      		leaves.add(leafB);
      		
      		parent.setLeft(leafA);
      		parent.setRight(leafB);

      		parent.setStr(Hashing.cryptHash(leafA.getStr() + leafB.getStr()));

      		return parent;
		}
	}

	/**
	 * When a client asks for a file, the algorithm will also send an arrayList.
	 * Holding the siblingPairs from the file node to the root.
	 * @param fileIndex an integer representing the file
	 * @return ArrayList an arrayList of the siblingPairs
	 */
	public ArrayList<SiblingPair<String>> sendAppr(int fileIndex){
		//Task 4: You are required to develop the code for the sendAppr method.
		//Running time complexity of this method: O(logn)
		//throw IllegalArgumentException for invalid parameters

		//The file index cannot be less than zero or greater than the size of leaves
		if (fileIndex < 0 || fileIndex >= leaves.size()){
			throw new IllegalArgumentException();
		}

		//if ConstructMerkle was never called throw an error
		if (root == null){
			throw new IllegalArgumentException();
		}
		ArrayList<SiblingPair<String>> siblingPath = new ArrayList<SiblingPair<String>>();

		MerkleTreeNode fileNode = leaves.get(fileIndex);

		//return the output of a resurive method		
		return fileOrder(fileNode.getParent(), siblingPath);
	}

	/**
	 * Private recursive helper method: traverers the tree from file node to the root.
	 * @param parent the current parent: parent of leaf - root.
	 * @param siblingPath the arrayList holding the siblingPairs.
	 * @return ArrayList of siblingPairs.
	 */
	private ArrayList<SiblingPair<String>> fileOrder(MerkleTreeNode parent, ArrayList<SiblingPair<String>> siblingPath){

		if (parent.equals(root)){
			//base case: the parent is the root
			//create a siblingPair for the children of root
			SiblingPair<String> siblings = new SiblingPair<String>(parent.getLeft().getStr(), parent.getRight().getStr());
			siblingPath.add(siblings);

			//create a siblingPair for the root
			SiblingPair<String> rootPair = new SiblingPair<String>(parent.getStr(), null);
			siblingPath.add(rootPair);

			//return the COMPLETED arrayList
			return siblingPath;
		}

		else{
			//depth - 1: Start with the parent of the files

			//create a siblingPair for the children of parent
			SiblingPair<String> siblings = new SiblingPair<String>(parent.getLeft().getStr(), parent.getRight().getStr());
			siblingPath.add(siblings);

			//recursive call using the parent of parent
			return fileOrder(parent.getParent(), siblingPath);
		}
	}

	
	/**
	 * Method to Verify the Integrity of the arrayList.
	 * @param aprr arrayList of the route from file to root.
	 * @param rootValue the consumers given root.
	 * @return boolean ensuring nothing has been corrupted.
	 */
	public static boolean verifyIntegrity(ArrayList<SiblingPair<String>> aprr, String rootValue){
		//Task 5: You are required to develop the code for the verifyIntegrity method
		//Running time complexity of this method: O(logn)
		
		//throw IllegalArgumentException for invalid parameters
		if (aprr == null || rootValue == null){
			throw new IllegalArgumentException();
		}

		//If ConstructMerkle was never called, the root would be null
		if (root == null){
			throw new IllegalArgumentException();
		}

		//If the rootValue does not equal root, the file has been corrupted
		if (!(rootValue.equals(root.getStr()))){
			return false;
		}
		//Calls a method that recursively verifies the integrity	
		return recursiveVerify(aprr, 0);
	}

	/**
	 * Private recurisve helper function.
	 * @param aprr the arrayList of the route.
	 * @param index which element in the array.
	 * @return boolean the integrity.
	 */
	private static boolean recursiveVerify(ArrayList<SiblingPair<String>> aprr, int index){

		//base case: second to last element in aprr
		if (index == aprr.size()-2){

			//Verify the hash of the two siblings is equal to one of the siblings in the next element
			String cryptHash = Hashing.cryptHash(aprr.get(index).getLeftSibling() + aprr.get(index).getRightSibling());

			if (!(cryptHash.equals(aprr.get(index+1).getLeftSibling()) || cryptHash.equals(aprr.get(index+1).getRightSibling()))){
				return false;
			}
			else{
				return true;
			}

		}
		else{
			//Saves the crypted Hash of the two siblings
			String cryptHash = Hashing.cryptHash(aprr.get(index).getLeftSibling() + aprr.get(index).getRightSibling());

			//check if they are equal to one of the siblings in the next pair
			if (!(cryptHash.equals(aprr.get(index+1).getLeftSibling()) || cryptHash.equals(aprr.get(index+1).getRightSibling()))){
				return false;
			}
			//Repeat for next sibling pair
			return recursiveVerify(aprr, index + 1);
		}
	}

	/**
	 * Replace a files contents.
	 * @param fileIndex the file to be replaced.
	 * @param updatedFile the new data.
	 * @return the updated root.
	 */
	public String replaceFile(int fileIndex, String updatedFile){
		//Task 6: You are required to develop the code for the replaceFile method.
		//Running time complexity of this method: O(logn)
		//throw IllegalArgumentException for invalid parameters
		
		//If ConstructMerkle was never called, the root would be null
		if (root == null){
			throw new IllegalArgumentException();
		}	
		
		if (fileIndex < 0 || fileIndex >= leaves.size()){
			throw new IllegalArgumentException();
		}

		if (updatedFile == null){
			throw new IllegalArgumentException();
		}

		//update the file's data
		MerkleTreeNode fileNode = leaves.get(fileIndex);
		fileNode.setStr(updatedFile);

		//recursively updates all parent nodes of updated File
		return changeHash(fileNode.getParent());

	}

	/**
	 * Private Recursive helper method.
	 * @param parent Current Parent: leaf's parent to the root.
	 * @return String the updated data of parent.
	 */
	private String changeHash(MerkleTreeNode parent){

		//base case: Parent == root
		if (root.equals(parent)){
			//change the root's hash value
			String updatedHash = Hashing.cryptHash(parent.getLeft().getStr() + parent.getRight().getStr());
			root.setStr(updatedHash);

			//return the updated data of root
			return root.getStr();
		}

		else{
			//change the hash value
			String updatedHash = Hashing.cryptHash(parent.getLeft().getStr() + parent.getRight().getStr());
			parent.setStr(updatedHash);

			//return the root by calling function until base case
			return changeHash(parent.getParent());

		}
	}
}

