/**
 * This class is used to store each element in the Authentication Pairs Route to Root (APRR).
 * Task 2: Developed the constructor and the set and get methods of the leftSibling and rightSibling instance variables of this class.
 * @author Maha Shamseddine
 * @param <X> Type of input of SiblingPair class
 */
public class SiblingPair<X> {

    /** Public instatnce variable leftSibling.*/
    public X leftSibling;
    /** Public instatnce variable rightSibling.*/
    public X rightSibling;
    
    
    /**Parameterized Constructor.
     * @param leftS generic value left Sibling
     * @param rightS generic value right Sibling
     */
    public SiblingPair(X leftS, X rightS) {
        //throw IllegalArgumentException for invalid parameters

        //The left sibling must always hold a non null value
        if (leftS == null){
            throw new IllegalArgumentException();
        }

        leftSibling = leftS;
        rightSibling = rightS;
    }

    /**
     * non-param constuctor.
     */
    public SiblingPair(){
        leftSibling = null;
        rightSibling = null;
    }
   
    /**
     * Getter method for the LeftSibling.
     * @return X generic value
     */
    public X getLeftSibling() {
        return leftSibling;
    }
    
    /**
     * Getter method for the rightSibling.
     * @return X generic value
     */
    public X getRightSibling() {
        return rightSibling;
    }
}
